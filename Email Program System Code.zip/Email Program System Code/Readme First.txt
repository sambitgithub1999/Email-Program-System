This is a program by which you can create ID's on the computer itsels and send and recieve mail. Follow the following instructions:



The .txt file is the java source code. The .jar file is the compiled program. 